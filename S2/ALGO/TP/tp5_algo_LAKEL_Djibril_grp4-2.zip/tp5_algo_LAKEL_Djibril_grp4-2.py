import tkinter as tk
import random

#exo1

class vue_message(tk.Tk):
    def __init__(self, message="bienvenue !"):
        super().__init__()
        self.title("message")
        tk.Label(self, text=message).pack()
        tk.Button(self, text="quitter", command=self.destroy).pack()

#exo2

class vue_message2(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("message personalise")
        
        self.label = tk.Label(self, text="bienvenue !")
        self.label.pack()
        
        self.entry = tk.Entry(self)
        self.entry.pack()
        
        button_frame = tk.Frame(self)
        button_frame.pack()
        
        tk.Button(button_frame, text="valider", command=self.valider).pack(side=tk.LEFT)
        tk.Button(button_frame, text="quitter", command=self.destroy).pack(side=tk.LEFT)
    
    def valider(self):
        self.label.config(text=f"bienvenue {self.entry.get()} !")

#exo3

dim = 21
images_filenames = ["rien.gif", "un.gif", "deux.gif", "trois.gif", "quatre.gif", "cinq.gif", "six.gif", "sept.gif", "huit.gif", "mine.gif", "flag.gif", "cache.gif"]

class vue_demineur(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("demineur")
        self.images = self.initialisation_images()
        
        self.canvas = tk.Canvas(self, width=dim, height=dim)
        self.canvas.pack()
        
        self.image_id = self.canvas.create_image(0, 0, anchor=tk.NW, image=random.choice(self.images))
        
        tk.Button(self, text="au revoir", command=self.destroy).pack()
    
    def initialisation_images(self):
        return [tk.PhotoImage(file=img) for img in images_filenames]

#exo4-5

class vue_demineur_multi(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("demineur 5 images")
        self.images = self.initialisation_images()
        
        self.canvas = tk.Canvas(self, width=5*dim, height=dim)
        self.canvas.pack()
        
        self.afficher_images()
        
        tk.Button(self, text="rejouer", command=self.afficher_images).pack()
        tk.Button(self, text="quitter", command=self.destroy).pack()
    
    def initialisation_images(self):
        return [tk.PhotoImage(file=img) for img in images_filenames]
    
    def afficher_images(self):
        self.canvas.delete("all")
        for i in range(5):
            self.canvas.create_image(i*dim, 0, anchor=tk.NW, image=random.choice(self.images))

#exo6

class vue_demineur_grille(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("demineur 5x5")
        self.images = self.initialisation_images()
        
        self.canvas = tk.Canvas(self, width=5*dim, height=5*dim)
        self.canvas.pack()
        
        self.afficher_images()
        
        tk.Button(self, text="rejouer", command=self.afficher_images).pack()
        tk.Button(self, text="quitter", command=self.destroy).pack()
    
    def initialisation_images(self):
        return [tk.PhotoImage(file=img) for img in images_filenames]
    
    def afficher_images(self):
        self.canvas.delete("all")
        for i in range(5):
            for j in range(5):
                self.canvas.create_image(j*dim, i*dim, anchor=tk.NW, image=random.choice(self.images))

app = vue_demineur_grille()
app.mainloop()

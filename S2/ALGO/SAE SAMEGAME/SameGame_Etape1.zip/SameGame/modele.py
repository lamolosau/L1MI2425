import random
import os

class Case:
    def __init__(self, couleur):
        self._couleur = couleur
    
    def get_couleur(self):
        return self._couleur
    
    def change_couleur(self, couleur):
        self._couleur = couleur
    
    def supprime(self):
        self._couleur = -1
    
    def est_vide(self):
        return self._couleur == -1

class ModeleSame:
    def __init__(self, nblig=10, nbcol=15):
        self.nblig = nblig
        self.nbcol = nbcol
        
        img_dir = "img/"
        available_files = os.listdir(img_dir)
        self.couleurs_disponibles = sorted([
            int(f.split("sphere")[1].split(".gif")[0])
            for f in available_files if "medium_sphere" in f and "black" not in f and "vide" not in f
        ])
        self.nbcouleurs = len(self.couleurs_disponibles)
        
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(nbcol)] for _ in range(nblig)]
        self.score = 0
    
    def get_nblig(self):
        return self.nblig
    
    def get_nbcol(self):
        return self.nbcol
    
    def get_nbcouleurs(self):
        return self.nbcouleurs
    
    def get_score(self):
        return self.score
    
    def coords_valides(self, i, j):
        return 0 <= i < self.nblig and 0 <= j < self.nbcol
    
    def get_couleur(self, i, j):
        return self.mat[i][j].get_couleur()
    
    def supprime_bille(self, i, j):
        if self.coords_valides(i, j):
            self.mat[i][j].supprime()
    
    def nouvelle_partie(self):
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(self.nbcol)] for _ in range(self.nblig)]
        self.score = 0
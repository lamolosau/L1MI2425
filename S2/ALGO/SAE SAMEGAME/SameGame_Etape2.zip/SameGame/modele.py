import random
import os

class Case:
    def __init__(self, couleur):
        self._couleur = couleur
        self.compo = -1
    
    def get_couleur(self):
        return self._couleur
    
    def change_couleur(self, couleur):
        self._couleur = couleur
        self.compo = -1
    
    def supprime(self):
        self._couleur = -1
        self.compo = 0
    
    def est_vide(self):
        return self._couleur == -1
    
    def composante(self):
        return self.compo
    
    def pose_composante(self, num):
        self.compo = num
    
    def supprime_compo(self):
        self.compo = 0 if self.est_vide() else -1
    
    def parcourue(self):
        return self.compo != -1

class ModeleSame:
    def nouvelle_partie(self):
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(self.nbcol)] for _ in range(self.nblig)]
        self.score = 0
        self.calcule_composantes()
    def __init__(self, nblig=10, nbcol=15):
        self.nblig = nblig
        self.nbcol = nbcol
        
        img_dir = "img/"
        available_files = os.listdir(img_dir)
        self.couleurs_disponibles = sorted([
            int(f.split("sphere")[1].split(".gif")[0])
            for f in available_files if "medium_sphere" in f and "black" not in f and "vide" not in f
        ])
        self.nbcouleurs = len(self.couleurs_disponibles)
        
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(nbcol)] for _ in range(nblig)]
        self.score = 0
        self.nb_elts_compo = []
        self.calcule_composantes()
    
    def get_score(self):
        return self.score
    
    def coords_valides(self, i, j):
        return 0 <= i < self.nblig and 0 <= j < self.nbcol
    
    def get_couleur(self, i, j):
        return self.mat[i][j].get_couleur()
    
    def composante(self, i, j):
        return self.mat[i][j].composante()
    
    def calcule_composantes(self):
        self.nb_elts_compo = [0]
        num_compo = 1
        for i in range(self.nblig):
            for j in range(self.nbcol):
                if self.mat[i][j].composante() == -1:
                    couleur = self.mat[i][j].get_couleur()
                    nb_elements = self.calcule_composante_numero(i, j, num_compo, couleur)
                    self.nb_elts_compo.append(nb_elements)
                    num_compo += 1
    
    def calcule_composante_numero(self, i, j, num_compo, couleur):
        if not self.coords_valides(i, j) or self.mat[i][j].parcourue() or self.mat[i][j].get_couleur() != couleur:
            return 0
        
        self.mat[i][j].pose_composante(num_compo)
        return (1 +
                self.calcule_composante_numero(i-1, j, num_compo, couleur) +
                self.calcule_composante_numero(i+1, j, num_compo, couleur) +
                self.calcule_composante_numero(i, j-1, num_compo, couleur) +
                self.calcule_composante_numero(i, j+1, num_compo, couleur))
    
    def recalc_composantes(self):
        for i in range(self.nblig):
            for j in range(self.nbcol):
                self.mat[i][j].supprime_compo()
        self.calcule_composantes()
    
    def supprime_composante(self, num_compo):
        if self.nb_elts_compo[num_compo] < 2:
            return False
        
        for i in range(self.nblig):
            for j in range(self.nbcol):
                if self.mat[i][j].composante() == num_compo:
                    self.mat[i][j].supprime()
        
        self.score += (self.nb_elts_compo[num_compo] - 2) ** 2
        self.recalc_composantes()
        return True
import tkinter as tk
import os
from modele import ModeleSame

class VueSame(tk.Tk):

    def __init__(self, modele):
        super().__init__()
        self.modele = modele
        self.title("SameGame")
        
        self.images = {}
        img_dir = "img/"
        available_files = os.listdir(img_dir)
        for couleur in self.modele.couleurs_disponibles:
            image_filename = f"medium_sphere{couleur}.gif"
            image_path = os.path.join(img_dir, image_filename)
            if image_filename in available_files:
                self.images[couleur] = tk.PhotoImage(file=image_path)
        
        self.images[-1] = tk.PhotoImage(file="img/medium_spherevide.gif")
        
        self.frame = tk.Frame(self)
        self.frame.pack()
        self.les_btns = [[tk.Button(self.frame, image=self.images.get(self.modele.get_couleur(i, j), self.images[-1]), command=self.creer_controleur_btn(i, j)) for j in range(self.modele.nbcol)] for i in range(self.modele.nblig)]
        
        for i in range(self.modele.nblig):
            for j in range(self.modele.nbcol):
                self.les_btns[i][j].grid(row=i, column=j)
        
        self.label_score = tk.Label(self, text=f"Score: {self.modele.get_score()}")
        self.label_score.pack()
        
        self.bouton_reset = tk.Button(self, text="Nouvelle Partie", command=self.nouvelle_partie)
        self.bouton_reset.pack()
    
    def nouvelle_partie(self):
        self.modele.nouvelle_partie()
        self.redessine()

    def redessine(self):
        for i in range(self.modele.nblig):
            for j in range(self.modele.nbcol):
                self.les_btns[i][j].config(image=self.images.get(self.modele.get_couleur(i, j), self.images[-1]))
        self.label_score.config(text=f"Score: {self.modele.get_score()}")
    
    def creer_controleur_btn(self, i, j):
        def controleur_btn():
            self.modele.supprime_composante(self.modele.composante(i, j))
            self.redessine()
        return controleur_btn

if __name__ == "__main__":
    modele = ModeleSame()
    vue = VueSame(modele)
    vue.mainloop()

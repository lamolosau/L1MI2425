from vue import *

if __name__ == "__main__":
    modele = ModeleSame()
    vue = VueSame(modele)
    vue.mainloop()
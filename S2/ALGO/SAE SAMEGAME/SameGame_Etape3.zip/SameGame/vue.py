import tkinter as tk
import os
from modele import ModeleSame

class VueSame(tk.Tk):

    def __init__(self, modele):
        super().__init__()
        self.modele = modele
        self.title("SameGame")
        
        self.images = {}
        img_dir = "img/"
        available_files = os.listdir(img_dir)
        for couleur in self.modele.couleurs_disponibles:
            # Try different sphere sizes as fallback
            for size in ["medium", "grand", "petit", "tres_petit"]:
                image_filename = f"{size}_sphere{couleur}.gif"
                if image_filename in available_files:
                    self.images[couleur] = tk.PhotoImage(file=os.path.join(img_dir, image_filename))
                    break
        
        self.images[-1] = tk.PhotoImage(file="img/medium_spherevide.gif")
        
        # FRAME PRINCIPAL
        self.conteneur = tk.Frame(self)
        self.conteneur.pack()

        # FRAME JEU À GAUCHE
        self.frame_grille = tk.Frame(self.conteneur)
        self.frame_grille.grid(row=0, column=0)

        # FRAME CONTROLES À DROITE
        self.frame_controles = tk.Frame(self.conteneur)
        self.frame_controles.grid(row=0, column=1, padx=20)

        # INIT GRILLE
        self.les_btns = [[tk.Button(self.frame_grille, image=self.images.get(self.modele.get_couleur(i, j), self.images[-1]),
                                command=self.creer_controleur_btn(i, j))
                      for j in range(self.modele.nbcol)] for i in range(self.modele.nblig)]
        for i in range(self.modele.nblig):
            for j in range(self.modele.nbcol):
                self.les_btns[i][j].grid(row=i, column=j)

        # SCORE & BOUTON À DROITE
        self.label_score = tk.Label(self.frame_controles, text=f"Score: {self.modele.get_score()}")
        self.label_score.pack(pady=10)

        self.bouton_reset = tk.Button(self.frame_controles, text="Nouvelle Partie", command=self.nouvelle_partie)
        self.bouton_reset.pack(pady=10)
    
    def nouvelle_partie(self):
        self.modele.nouvelle_partie()
        self.redessine()

    def redessine(self):
        if len(self.les_btns[0]) != self.modele.nbcol:
            # On supprime proprement tous les boutons
            for widget in self.frame_grille.winfo_children():
                widget.destroy()

            self.les_btns = [[tk.Button(self.frame_grille, image=self.images.get(self.modele.get_couleur(i, j), self.images[-1]),
                                command=self.creer_controleur_btn(i, j))
                      for j in range(self.modele.nbcol)] for i in range(self.modele.nblig)]

            for i in range(self.modele.nblig):
                for j in range(self.modele.nbcol):
                    self.les_btns[i][j].grid(row=i, column=j)
        else:
            for i in range(self.modele.nblig):
                for j in range(self.modele.nbcol):
                    self.les_btns[i][j].config(image=self.images.get(self.modele.get_couleur(i, j), self.images[-1]))

        self.label_score.config(text=f"Score: {self.modele.get_score()}")
    
    def creer_controleur_btn(self, i, j):
        def controleur_btn():
            self.modele.supprime_composante(self.modele.composante(i, j))
            self.redessine()
        return controleur_btn

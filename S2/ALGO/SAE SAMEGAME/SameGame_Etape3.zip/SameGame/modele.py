import random
import os

class Case:
    def __init__(self, couleur):
        self._couleur = couleur
        self.compo = -1
    
    def get_couleur(self):
        return self._couleur
    
    def change_couleur(self, couleur):
        self._couleur = couleur
        self.compo = -1
    
    def supprime(self):
        self._couleur = -1
        self.compo = 0
    
    def est_vide(self):
        return self._couleur == -1
    
    def composante(self):
        return self.compo
    
    def pose_composante(self, num):
        self.compo = num
    
    def supprime_compo(self):
        self.compo = 0 if self.est_vide() else -1
    
    def parcourue(self):
        return self.compo != -1

class ModeleSame:
    def nouvelle_partie(self):
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(self.nbcol)] for _ in range(self.nblig)]
        self.score = 0
        self.nb_elts_compo = [0]
        self.calcule_composantes()
    def __init__(self, nblig=10, nbcol=15):
        self.nblig = nblig
        self.nbcol = nbcol
        
        img_dir = "img/"
        available_files = os.listdir(img_dir)
        self.couleurs_disponibles = sorted([
            int(f.split("sphere")[1].split(".gif")[0])
            for f in available_files 
            if "sphere" in f and "black" not in f and "vide" not in f 
            and f.endswith(".gif") and f.split("sphere")[1].split(".gif")[0].isdigit()
        ])
        self.nbcouleurs = len(self.couleurs_disponibles)
        
        self.mat = [[Case(random.choice(self.couleurs_disponibles)) for _ in range(nbcol)] for _ in range(nblig)]
        self.score = 0
        self.nb_elts_compo = []
        self.calcule_composantes()
    
    def get_score(self):
        return self.score
    
    def coords_valides(self, i, j):
        return 0 <= i < self.nblig and 0 <= j < self.nbcol
    
    def get_couleur(self, i, j):
        return self.mat[i][j].get_couleur()
    
    def est_vide(self, i, j):
        return self.mat[i][j].est_vide()
    
    def composante(self, i, j):
        return self.mat[i][j].composante()
    
    def calcule_composantes(self):
        self.nb_elts_compo = [0]
        num_compo = 1
        for i in range(self.nblig):
            for j in range(self.nbcol):
                if self.mat[i][j].composante() == -1:
                    couleur = self.mat[i][j].get_couleur()
                    nb_elements = self.calcule_composante_numero(i, j, num_compo, couleur)
                    self.nb_elts_compo.append(nb_elements)
                    num_compo += 1
    
    def calcule_composante_numero(self, i, j, num_compo, couleur):
        if not self.coords_valides(i, j):
            return 0
        if self.mat[i][j].parcourue():
            return 0
        if self.mat[i][j].get_couleur() != couleur:
            return 0
        
        self.mat[i][j].pose_composante(num_compo)
        count = 1
        
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for di, dj in directions:
            ni, nj = i + di, j + dj
            count += self.calcule_composante_numero(ni, nj, num_compo, couleur)
        
        return count
    
    def recalc_composantes(self):
        for i in range(self.nblig):
            for j in range(self.nbcol):
                if self.mat[i][j].est_vide():
                    self.mat[i][j].compo = 0
                else:
                    self.mat[i][j].compo = -1
        
        self.calcule_composantes()
    
    def supprime_composante_colonne(self, j, num_compo):
        for i in range(self.nblig):
            if self.mat[i][j].composante() == num_compo:
                self.mat[i][j].supprime()

        new_col = [self.mat[i][j] for i in range(self.nblig) if not self.mat[i][j].est_vide()]
        nb_vide = self.nblig - len(new_col)
        new_col = [Case(-1) for _ in range(nb_vide)] + new_col
        for i in range(self.nblig):
            self.mat[i][j] = new_col[i]

    def supprime_composante(self, num_compo):
        if self.nb_elts_compo[num_compo] < 2:
            return False

        for j in range(self.nbcol):
            self.supprime_composante_colonne(j, num_compo)

        self.score += (self.nb_elts_compo[num_compo] - 2) ** 2

        self.supprime_colonnes_vides()

        self.recalc_composantes()
        return True

    def supprime_colonnes_vides(self):
        colonnes_non_vides = []
        for j in range(self.nbcol):
            est_vide = True
            for i in range(self.nblig):
                if not self.mat[i][j].est_vide():
                    est_vide = False
                    break
            if not est_vide:
                col = [self.mat[i][j] for i in range(self.nblig)]
                colonnes_non_vides.append(col)

        nb_vides = self.nbcol - len(colonnes_non_vides)
        colonnes_vides = [[Case(-1) for _ in range(self.nblig)] for _ in range(nb_vides)]

        nouvelles_colonnes = colonnes_non_vides + colonnes_vides
        for i in range(self.nblig):
            for j in range(self.nbcol):
                self.mat[i][j] = nouvelles_colonnes[j][i]

        self.recalc_composantes()
